-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Mar 2025 pada 07.17
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pkl_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `nama_peserta`
--

CREATE TABLE `nama_peserta` (
  `id_peserta` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telepon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `nama_peserta`
--

INSERT INTO `nama_peserta` (`id_peserta`, `nama`, `email`, `password`, `jenis_kelamin`, `alamat`, `telepon`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', 'L', 'Jl. Malang', '082222222222'),
(2, 'Bryant Anthony', 'bryantanthonykores@gmail.com', 'LSDKV', 'L', 'Jl Ikan Mas Buntu', '1245'),
(3, 'Bryant Anthony', 'bryantanthonykores@gmail.com', 'LSDKV', 'L', 'Jl Ikan Mas Buntu', '1245'),
(4, 'qw', 'asdasd@asd', 'asdasd', 'L', 'asdasd', 'asdasd');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `nama_peserta`
--
ALTER TABLE `nama_peserta`
  ADD PRIMARY KEY (`id_peserta`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `nama_peserta`
--
ALTER TABLE `nama_peserta`
  MODIFY `id_peserta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
